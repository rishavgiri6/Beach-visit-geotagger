import requests,datetime
import time as tmt
import pandas as pd
from pysolar.solar import *
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')
def send_rad(lat,long,date=datetime.datetime.now()):
    #df=pd.read_csv('Beach_data_fin.csv')
    #lat,long=df.iloc[nm]['Coordinates'].split(',')
    date-=datetime.timedelta(hours=3)
    D={}
    for i in range(1,12):
        cdt=date+datetime.timedelta(hours=i)
        altitude_deg = get_altitude(float(lat), float(long), cdt)
        rad = radiation.get_radiation_direct(cdt, altitude_deg)
        if rad<100 or rad>12000:
            continue
        ind=cdt.strftime('%x %H')
        D[ind]=rad
    return D

def my_func(lat,long):
    #df = pd.read_csv("Beach_data_fin.csv")
    req=requests.get('https://api.darksky.net/forecast/f03aad3d4eaea1b8509ddbc6f8fdaad4/{},{}'.format(lat,long))
    data=req.json()['hourly']['data']
    weather=dict()
    a = datetime.datetime.now()
    for i in range (len(data)):
        weather[a.strftime('%x %H')]=data[i]['summary']
        a=a+datetime.timedelta(hours=1)
    return weather

def combine(rad,wea):
    tm=rad.keys()
    f={}
    for k in tm:
        if k in wea.keys():
            f[k]={}
            f[k]['rad']=rad[k]
            f[k]['wea']=wea[k]

    return f
def get_status_point(st):
    status={}
    status['Rain']=3
    status['Light Rain']=4
    status['Foggy']=5
    status['Mostly Cloudy']=12
    status['Breezy']=9
    status['Windy']=6
    status['Possible Light Rain']=8
    status['Partly Cloudy']=11.5
    status['Heavy Rain']=0
    status['Dangerously Windy']=1
    status['Overcast']=10
    status['Clear']=13
    status['Humid']=7
    st=st.split(' and ')
    pt=0
    for det in st:
        pt+=status[det]
    return pt

def get_rad_point(pt):
    sim=pt/600
    return (20-sim)

def prediction(det):
    de={}
    for k in det:
        de[k]=get_status_point(det[k]['wea'])+get_rad_point(det[k]['rad'])
    s_de=sorted(de,key=de.get,reverse=True)
    plt.plot(de.keys(),de.values(),'g*',marker='o', linestyle='dashed',color='r',linewidth=1)
    plt.xlabel('Date and Hour of the day',color='g')
    plt.ylabel('Prority based on weather & radiation',color='b')
    plt.annotate('Local Max1',xy=(s_de[0],de[s_de[0]]),xytext=(s_de[0],de[s_de[0]]-0.2),arrowprops=dict(facecolor='m',shrink=0.05))
    plt.annotate('Local Max2',xy=(s_de[1],de[s_de[1]]),xytext=(s_de[1],de[s_de[1]]-0.2),arrowprops=dict(facecolor='m',shrink=0.05))
    plt.annotate('Local Max3',xy=(s_de[2],de[s_de[2]]),xytext=(s_de[2],de[s_de[2]]-0.2),arrowprops=dict(facecolor='m',shrink=0.05))
    #plt.legend()
    plt.title('Beach Visit Recommendation System')
    return s_de[:3]
                                                                         
from googlegeocoder import GoogleGeocoder
def beach_lat_long(name):
    ctr,c=0,0
    result=dict()
    result['Beach name']=name
    geocoder = GoogleGeocoder()
    try:
        search = geocoder.get(name)
    except ValueError:
        c=1
        while(ctr<10):
            ctr = ctr + 1
            try:
                search = geocoder.get(name)
            except ValueError:
                continue
            result['Latitude'] = search[0].geometry.location.lat
            result['Longitude']= search[0].geometry.location.lng
            break
    if (c is 0):
        result['Latitude'] = search[0].geometry.location.lat
        result['Longitude'] = search[0].geometry.location.lng

    return result
def get_prediction(name,date):
    lat_long=beach_lat_long(name)
    print('\nThe Latitude and Longitude of the given location {} is ({},{})'.format(name,lat_long['Latitude'],lat_long['Longitude'])) 
    pred=prediction(combine(send_rad(lat_long['Latitude'],lat_long['Longitude'],date),my_func(lat_long['Latitude'],lat_long['Longitude'])))
    print('\nTop 3 time Recommendation to visit the beach {} are (%mm/%dd/%yyyy %HH):'.format(name))
    print('\ntop Recommendation : {}'.format(pred[0]))
    print('\nnext Recommendation : {}'.format(pred[1]))
    print('\nnext Recommendation : {}'.format(pred[2]))
    tmt.sleep(2)
    plt.show()
    

print("\t\t!!Welcome to the Beach Visit time recommendation system!!")
print("\nEnter the Beach name you want to visit :",end='')
name=str(input())
print('\nDo you want to visit now or later( 1 - now,2 - later):',end='')
ch=int(input())
if(ch==1):
    date=datetime.datetime.now()
elif(ch==2):
    print("\nEnter the your visiting date and time in the given format(%dd/%mm/%yyyy %HH(24 hrs format)).\n\n !!Note: please give the date with in 36 hours from now to get the better recommendation.\n\nEnter the date : ",end='')
    dt=str(input())
    date=datetime.datetime.strptime(dt,'%d/%m/%Y %H')
print('\nGetting the Recommendations best for you')
get_prediction(name,date)
print("\t\t\tTHANK YOU")
